package cl.douc.biblioteca.serviciolibros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiciolibrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
