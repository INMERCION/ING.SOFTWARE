package cl.douc.biblioteca.servicioprestamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioprestamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioprestamoApplication.class, args);
	}

}
