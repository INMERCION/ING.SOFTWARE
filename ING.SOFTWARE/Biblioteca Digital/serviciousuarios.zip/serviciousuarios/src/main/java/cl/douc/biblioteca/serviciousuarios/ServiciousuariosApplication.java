package cl.douc.biblioteca.serviciousuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiciousuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiciousuariosApplication.class, args);
	}

}
